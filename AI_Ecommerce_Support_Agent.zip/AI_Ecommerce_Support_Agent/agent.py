"""Agentic AI core using Anthropic tool calling and conversation memory."""
import json
import os
import anthropic

from tools import TOOL_SCHEMAS, TOOL_FUNCTIONS
from memory import ConversationMemory, LongTermMemory

# Override with ANTHROPIC_MODEL if your account uses a different model name.
MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-5")

SYSTEM_PROMPT_TEMPLATE = """You are a helpful, friendly customer support agent for an online store.

You can:
- Look up order status and tracking information.
- Check return eligibility and initiate returns.
- Search the product catalog and answer product questions.
- Recommend products based on a customer's purchase history.

Rules:
- Always use the provided tools to look up real order statuses, stock levels, and prices.
- If a tool returns an error, explain it clearly and ask the customer to double-check the ID.
- Be concise, accurate, and warm.
- If a request is outside your scope, explain that it should be escalated to a human agent.
{long_term_context}
"""

class SupportAgent:
    def __init__(self, customer_id: str, api_key: str | None = None):
        api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY is not set. Add it to your environment before running the agent."
            )

        self.client = anthropic.Anthropic(api_key=api_key)
        self.customer_id = customer_id.upper()
        self.long_term = LongTermMemory()
        context = self.long_term.as_context_string(self.customer_id)
        system_prompt = SYSTEM_PROMPT_TEMPLATE.format(long_term_context=context)
        self.memory = ConversationMemory(system_prompt=system_prompt)

    def _execute_tool(self, name: str, tool_input: dict) -> dict:
        function = TOOL_FUNCTIONS.get(name)
        if not function:
            return {"error": f"Unknown tool '{name}'"}

        try:
            result = function(**tool_input)
            if name == "get_order_status" and "order_id" in tool_input:
                self.long_term.remember(
                    self.customer_id,
                    "last_order_discussed",
                    tool_input["order_id"].upper(),
                )
            return result
        except Exception as error:
            return {"error": f"Tool execution failed: {str(error)}"}

    def chat(self, user_message: str) -> str:
        self.memory.add_user_message(user_message)
        self.memory.trim()

        while True:
            response = self.client.messages.create(
                model=MODEL,
                max_tokens=1024,
                system=self.memory.system_prompt,
                tools=TOOL_SCHEMAS,
                messages=self.memory.get_messages(),
            )

            # Anthropic content can contain text and tool_use blocks.
            self.memory.add_assistant_message(response.content)

            if response.stop_reason != "tool_use":
                final_text = "".join(
                    block.text
                    for block in response.content
                    if getattr(block, "type", None) == "text"
                ).strip()
                return final_text or "I couldn't generate a response. Please try again."

            tool_results = []
            for block in response.content:
                if getattr(block, "type", None) == "tool_use":
                    result = self._execute_tool(block.name, block.input)
                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": json.dumps(result),
                        }
                    )

            self.memory.add_user_message(tool_results)

if __name__ == "__main__":
    print("=== AI E-Commerce Support Agent (type 'quit' to exit) ===")
    customer_id = input("Customer ID (e.g. C001): ").strip() or "C001"
    agent = SupportAgent(customer_id=customer_id)

    while True:
        user_input = input("\nYou: ").strip()
        if user_input.lower() in ("quit", "exit"):
            break
        if not user_input:
            continue
        print(f"\nAgent: {agent.chat(user_input)}")
