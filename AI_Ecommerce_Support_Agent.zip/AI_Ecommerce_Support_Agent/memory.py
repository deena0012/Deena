"""Short-term and long-term memory layers."""
import json
import os

LONG_TERM_PATH = os.path.join(os.path.dirname(__file__), "long_term_memory.json")

class ConversationMemory:
    def __init__(self, system_prompt: str):
        self.system_prompt = system_prompt
        self.messages = []

    def add_user_message(self, content):
        self.messages.append({"role": "user", "content": content})

    def add_assistant_message(self, content):
        self.messages.append({"role": "assistant", "content": content})

    def get_messages(self):
        return self.messages

    def trim(self, max_messages: int = 30):
        if len(self.messages) > max_messages:
            self.messages = self.messages[-max_messages:]

class LongTermMemory:
    def __init__(self, path: str = LONG_TERM_PATH):
        self.path = path
        self._data = self._load()

    def _load(self) -> dict:
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as file:
                    return json.load(file)
            except (json.JSONDecodeError, OSError):
                return {}
        return {}

    def _save(self):
        with open(self.path, "w", encoding="utf-8") as file:
            json.dump(self._data, file, indent=2)

    def get_profile(self, customer_id: str) -> dict:
        return self._data.get(customer_id, {})

    def remember(self, customer_id: str, key: str, value):
        profile = self._data.setdefault(customer_id, {})
        profile[key] = value
        self._save()

    def as_context_string(self, customer_id: str) -> str:
        profile = self.get_profile(customer_id)
        if not profile:
            return ""
        facts = "; ".join(f"{key}: {value}" for key, value in profile.items())
        return f"Known context about this customer from past interactions: {facts}"
