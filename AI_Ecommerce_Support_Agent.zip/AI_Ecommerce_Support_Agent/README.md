# AI-Powered E-Commerce Customer Support Agent

An agentic AI customer-support project that handles:

- Order status and tracking
- Return eligibility and return initiation
- Product search and product details
- Personalized product recommendations
- Short-term conversation memory
- JSON-backed long-term customer memory
- REST API using FastAPI

## Project structure

```text
AI_Ecommerce_Support_Agent/
├── mock_data.py
├── tools.py
├── memory.py
├── agent.py
├── app.py
├── requirements.txt
├── .env.example
├── long_term_memory.json
└── README.md
```

## Installation

```bash
python -m venv .venv
```

Activate the virtual environment.

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Set your Anthropic API key:

Windows PowerShell:

```powershell
$env:ANTHROPIC_API_KEY="your_api_key_here"
```

Linux/macOS:

```bash
export ANTHROPIC_API_KEY="your_api_key_here"
```

Optionally set `ANTHROPIC_MODEL` to a model available in your account.

## Run the CLI

```bash
python agent.py
```

Example:

```text
Customer ID: C001
You: Where's my order ORD1001?
You: Can I return ORD1002?
You: Recommend something for me
```

## Run the FastAPI server

```bash
uvicorn app:app --reload
```

Open the interactive API documentation at:

```text
http://127.0.0.1:8000/docs
```

Example request:

```json
{
  "customer_id": "C001",
  "message": "Where's my order ORD1001?"
}
```

## Notes

The order/product/customer data is mock data. In a production deployment, replace it with database or API integrations.
