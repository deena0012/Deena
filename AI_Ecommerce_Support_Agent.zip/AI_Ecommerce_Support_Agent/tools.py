"""Callable tools for the AI E-Commerce Customer Support Agent."""
from datetime import datetime
from mock_data import PRODUCTS, CUSTOMERS, ORDERS

TODAY = datetime(2026, 9, 8)

def get_order_status(order_id: str) -> dict:
    order = ORDERS.get(order_id.upper())
    if not order:
        return {"error": f"No order found with ID '{order_id}'. Please double-check the order number."}
    return {
        "order_id": order["order_id"],
        "status": order["status"],
        "carrier": order["carrier"],
        "tracking_number": order["tracking_number"],
        "order_date": order["order_date"],
        "estimated_delivery": order["estimated_delivery"],
        "delivered_date": order.get("delivered_date"),
        "total": order["total"],
    }

def check_return_eligibility(order_id: str) -> dict:
    order = ORDERS.get(order_id.upper())
    if not order:
        return {"error": f"No order found with ID '{order_id}'."}
    if order["status"] != "Delivered":
        return {
            "eligible": False,
            "reason": f"Order is currently '{order['status']}'. Returns can only be initiated after delivery.",
        }

    delivered = datetime.strptime(order["delivered_date"], "%Y-%m-%d")
    days_since = (TODAY - delivered).days
    window = order["return_window_days"]
    if days_since <= window:
        return {
            "eligible": True,
            "days_remaining": window - days_since,
            "return_window_days": window,
        }
    return {
        "eligible": False,
        "reason": f"Return window of {window} days expired {days_since - window} day(s) ago.",
    }

def search_products(query: str, max_results: int = 5) -> dict:
    query_lower = query.lower()
    results = []
    for product in PRODUCTS.values():
        haystack = f"{product['name']} {product['category']} {product['description']}".lower()
        # Match the whole query or any useful keyword.
        if query_lower in haystack or any(word in haystack for word in query_lower.split() if len(word) > 2):
            results.append(product)
    return {"count": min(len(results), max_results), "products": results[:max_results]}

def get_product_details(product_id: str) -> dict:
    product = PRODUCTS.get(product_id.upper())
    if not product:
        return {"error": f"No product found with ID '{product_id}'."}
    return product

def recommend_products(customer_id: str, max_results: int = 3) -> dict:
    customer = CUSTOMERS.get(customer_id.upper())
    if not customer:
        return {"error": f"No customer found with ID '{customer_id}'."}

    bought_ids = set(customer["past_purchases"])
    bought_categories = {
        PRODUCTS[pid]["category"] for pid in bought_ids if pid in PRODUCTS
    }

    recommendations = [
        product for pid, product in PRODUCTS.items()
        if pid not in bought_ids
        and product["category"] in bought_categories
        and product["stock"] > 0
    ]
    if not recommendations:
        recommendations = [
            product for pid, product in PRODUCTS.items()
            if pid not in bought_ids and product["stock"] > 0
        ]

    recommendations = sorted(
        recommendations, key=lambda product: product["rating"], reverse=True
    )[:max_results]

    return {
        "customer_name": customer["name"],
        "loyalty_tier": customer["loyalty_tier"],
        "recommendations": recommendations,
    }

def initiate_return(order_id: str, reason: str) -> dict:
    eligibility = check_return_eligibility(order_id)
    if not eligibility.get("eligible"):
        return {
            "success": False,
            "message": eligibility.get("reason", "Not eligible for return."),
        }
    return {
        "success": True,
        "order_id": order_id.upper(),
        "return_id": f"RTN-{order_id.upper()}-01",
        "reason_logged": reason,
        "message": "Return initiated. A prepaid shipping label has been emailed to the customer.",
    }

TOOL_SCHEMAS = [
    {
        "name": "get_order_status",
        "description": "Get the shipping/delivery status of an order by order ID.",
        "input_schema": {
            "type": "object",
            "properties": {"order_id": {"type": "string", "description": "e.g. ORD1001"}},
            "required": ["order_id"],
        },
    },
    {
        "name": "check_return_eligibility",
        "description": "Check if an order is still within its return window.",
        "input_schema": {
            "type": "object",
            "properties": {"order_id": {"type": "string"}},
            "required": ["order_id"],
        },
    },
    {
        "name": "search_products",
        "description": "Search the product catalog by keyword, name, category, or description.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "max_results": {"type": "integer", "description": "Default 5"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_product_details",
        "description": "Get full details for one product by ID.",
        "input_schema": {
            "type": "object",
            "properties": {"product_id": {"type": "string"}},
            "required": ["product_id"],
        },
    },
    {
        "name": "recommend_products",
        "description": "Get personalized product recommendations based on purchase history.",
        "input_schema": {
            "type": "object",
            "properties": {
                "customer_id": {"type": "string"},
                "max_results": {"type": "integer", "description": "Default 3"},
            },
            "required": ["customer_id"],
        },
    },
    {
        "name": "initiate_return",
        "description": "Start a return for an eligible order, given a reason.",
        "input_schema": {
            "type": "object",
            "properties": {
                "order_id": {"type": "string"},
                "reason": {"type": "string"},
            },
            "required": ["order_id", "reason"],
        },
    },
]

TOOL_FUNCTIONS = {
    "get_order_status": get_order_status,
    "check_return_eligibility": check_return_eligibility,
    "search_products": search_products,
    "get_product_details": get_product_details,
    "recommend_products": recommend_products,
    "initiate_return": initiate_return,
}
