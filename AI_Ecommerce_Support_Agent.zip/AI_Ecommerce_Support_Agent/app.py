"""FastAPI wrapper for the AI E-Commerce Customer Support Agent."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from agent import SupportAgent

app = FastAPI(
    title="AI E-Commerce Support Agent",
    description="Agentic customer support with tool calling and memory.",
    version="1.0.0",
)

_sessions: dict[str, SupportAgent] = {}

class ChatRequest(BaseModel):
    customer_id: str
    message: str

class ChatResponse(BaseModel):
    reply: str

def get_or_create_session(customer_id: str) -> SupportAgent:
    customer_id = customer_id.upper()
    if customer_id not in _sessions:
        _sessions[customer_id] = SupportAgent(customer_id=customer_id)
    return _sessions[customer_id]

@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    try:
        agent = get_or_create_session(request.customer_id)
        return ChatResponse(reply=agent.chat(request.message))
    except ValueError as error:
        raise HTTPException(status_code=500, detail=str(error)) from error
    except Exception as error:
        raise HTTPException(status_code=500, detail=f"Agent error: {str(error)}") from error

@app.post("/reset/{customer_id}")
def reset_session(customer_id: str):
    _sessions.pop(customer_id.upper(), None)
    return {"status": "session cleared", "customer_id": customer_id.upper()}

@app.get("/health")
def health():
    return {"status": "ok"}
